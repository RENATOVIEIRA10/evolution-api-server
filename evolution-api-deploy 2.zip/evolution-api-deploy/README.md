# Evolution API - Deploy Gratuito no Render

Este repositório contém tudo pronto para fazer deploy da Evolution API gratuitamente no Render.com.

## 🚀 Passo a Passo Completo

### 1. Fazer Upload deste Repositório no GitHub

1. Acesse: https://github.com/new
2. Nome do repositório: `evolution-api-server`
3. Deixe como **Public**
4. **NÃO** marque "Add a README file"
5. Clique em **"Create repository"**

6. Na tela que aparecer, você verá comandos. **Ignore eles** e faça o upload manual:
   - Clique em **"uploading an existing file"**
   - Arraste TODOS os arquivos desta pasta (Dockerfile, docker-compose.yml, README.md)
   - Clique em **"Commit changes"**

### 2. Fazer Deploy no Render.com

1. Acesse: https://render.com/
2. Faça login com sua conta GitHub
3. Clique em **"New +"** (canto superior direito)
4. Escolha **"Web Service"**

5. Conecte seu repositório:
   - Clique em **"Connect a repository"**
   - Se pedir permissão, autorize o Render a acessar seus repositórios
   - Encontre o repositório `evolution-api-server`
   - Clique em **"Connect"**

6. Configure o serviço:
   - **Name**: `evolution-api` (ou qualquer nome que quiser)
   - **Region**: Escolha a mais próxima (ex: Oregon, Ohio, Frankfurt)
   - **Branch**: `main` (ou `master`)
   - **Runtime**: Escolha **"Docker"**
   - **Instance Type**: Escolha **"Free"**

7. Adicione as variáveis de ambiente:
   - Clique em **"Advanced"** ou role até **"Environment Variables"**
   - Adicione as seguintes variáveis:

   | Key | Value |
   |-----|-------|
   | `AUTHENTICATION_API_KEY` | `minha_chave_super_secreta_12345` (troque por uma senha forte!) |
   | `SERVER_URL` | `https://evolution-api.onrender.com` (vai ser gerada depois, pode deixar assim) |

8. Clique em **"Create Web Service"**

9. Aguarde o deploy (5-10 minutos). Você verá os logs na tela.

### 3. Pegar a URL do Servidor

Quando o deploy terminar:
1. No topo da página, você verá uma URL como: `https://evolution-api-xxxx.onrender.com`
2. **Copie essa URL** - você vai precisar dela!

### 4. Atualizar a Variável SERVER_URL

1. No painel do Render, vá em **"Environment"** (menu lateral)
2. Encontre a variável `SERVER_URL`
3. Clique em **"Edit"**
4. Cole a URL que você copiou no passo 3
5. Clique em **"Save Changes"**
6. O serviço vai reiniciar automaticamente

### 5. Testar se Está Funcionando

Abra no navegador: `https://sua-url.onrender.com`

Você deve ver uma página da Evolution API ou uma resposta JSON.

### 6. Criar uma Instância do WhatsApp

Agora vamos criar a conexão com o WhatsApp usando a API.

**Opção A: Usando o Terminal/Postman**

```bash
curl -X POST https://sua-url.onrender.com/instance/create \
  -H "Content-Type: application/json" \
  -H "apikey: minha_chave_super_secreta_12345" \
  -d '{
    "instanceName": "assistente-vendas",
    "qrcode": true,
    "integration": "WHATSAPP-BAILEYS"
  }'
```

**Opção B: Usando o navegador (mais fácil)**

Vou te dar um arquivo HTML que você pode abrir no navegador para fazer isso visualmente.

### 7. Obter o QR Code

```bash
curl -X GET https://sua-url.onrender.com/instance/connect/assistente-vendas \
  -H "apikey: minha_chave_super_secreta_12345"
```

A resposta terá um campo `base64` com a imagem do QR Code.

### 8. Conectar ao WhatsApp

1. Abra o WhatsApp no celular
2. Vá em **"Aparelhos Conectados"**
3. Toque em **"Conectar um aparelho"**
4. Escaneie o QR Code

### 9. Configurar na Sua Aplicação

Adicione os seguintes valores nos **Segredos** da sua aplicação:

| Nome | Valor |
|------|-------|
| `EVOLUTION_API_URL` | `https://sua-url.onrender.com` |
| `EVOLUTION_API_KEY` | `minha_chave_super_secreta_12345` |
| `EVOLUTION_INSTANCE_NAME` | `assistente-vendas` |

### 10. Testar!

Envie uma mensagem para o WhatsApp conectado:

```
Novo lead: João Silva, Acme Corp, (11) 99999-8888
```

Deve receber uma resposta confirmando! 🎉

## ⚠️ Importante sobre o Plano Gratuito do Render

- O servidor **hiberna após 15 minutos de inatividade**
- Quando receber a primeira mensagem, pode demorar ~30 segundos para "acordar"
- Para uso em produção, considere o plano pago ($7/mês) que mantém o servidor sempre ativo

## 🆘 Problemas Comuns

### Deploy falhou
- Verifique se o Dockerfile está correto
- Tente fazer o deploy novamente

### QR Code expirou
- O QR Code expira em 60 segundos
- Gere um novo com o comando do passo 7

### Mensagens não estão chegando
- Verifique se a instância está conectada
- Veja os logs no painel do Render

## 📞 Precisa de Ajuda?

Se tiver qualquer problema, me avise e eu te ajudo!

